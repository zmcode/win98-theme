<!--
 * @Author: dengzuming
 * @Date: 2022-08-09 09:55:45
 * @LastEditors: dengzuming
 * @LastEditTime: 2022-08-09 10:14:30
-->
## 介绍
基于perfree: [http://perfree.org.cn](http://perfree.org.cn)
基于win98: [https://github.com/1j01/98](https://github.com/1j01/98)
开发的win98怀旧主题

## 使用
根据perfree官网部署项目, 下载对应版本的Releases版本包, 安装主题即可

## 展示
![image](https://user-images.githubusercontent.com/48686959/183547464-bbd40b84-92c1-41cc-9830-0454fa69b513.png)
![image](https://user-images.githubusercontent.com/48686959/183547594-1b51dba9-87b6-4f84-8318-c425174143e2.png)
![image](https://user-images.githubusercontent.com/48686959/183547913-9ddb9e92-80bd-4010-83b7-0ae2caa5c6f9.png)
![image](https://user-images.githubusercontent.com/48686959/183548338-9da848a9-e6c1-4716-9ecd-b03ec79ec954.png)


